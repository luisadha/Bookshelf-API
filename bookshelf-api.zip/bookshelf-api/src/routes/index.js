import BookRoutes from "./books-routes.js";

const Routes = [...BookRoutes];

export default Routes;